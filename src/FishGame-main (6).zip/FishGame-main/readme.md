# FishGame
our game is based on the google dino game it will almost be the same mechanic the bigest different will be how the dino moves so in our case the fish moves, it will only move on the Y axes. There will be enemies to avoid and you survive for the longest that you can.

## Developers
Brianna - Main code, created the code.

Cora - Desighned fish and enemies along with bubbles. Dishned the start and end screen. Helped Jules with design.

Kalyis - Helped with bugs and fixes. Monitored our progress, leader.

Jules - Design for start, background, and end screen.

Prieston - Helped with code w/ move method.

Kainoa - Helped with code w/ enemies.


[Game Pictures](https://github.com/Dot310/FishGame/tree/main/images)

[SRC](https://github.com/Dot310/FishGame/tree/main/src)

![Start](https://github.com/Dot310/FishGame/blob/main/images/Start.png)

![Game](https://github.com/Dot310/FishGame/blob/main/images/Game.png)

![End](https://github.com/Dot310/FishGame/blob/main/images/End.png)
